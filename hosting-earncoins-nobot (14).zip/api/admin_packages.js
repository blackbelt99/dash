const fs = require("fs");
const settingsPath = "./settings.json";
const log = require("../misc/log");
const userLog = require("../misc/userLog");

module.exports.load = async function (app, db) {
  // Helper to verify admin status
  function isAdmin(req) {
    return req.session && req.session.pterodactyl && req.session.pterodactyl.root_admin === true;
  }

  // Save Packages and Roles configurations
  app.post("/api/admin/packages/save", async (req, res) => {
    if (!isAdmin(req)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

    const { defaultPackage, list, roleServer, roles } = req.body;
    if (!defaultPackage || typeof list !== "object") {
      return res.status(400).json({ success: false, message: "Invalid payload parameters." });
    }

    try {
      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());

      settings.api.client.packages = {
        default: defaultPackage,
        list: list,
        rolePackages: {
          note: "This allows you to set a different plan/package to people who have a specific Discord role. Requires a bot token under api.client.bot.token and the Server Boost / Role Mappings Guild ID below. This is mainly used for Boost rewards.",
          roleServer: roleServer || "",
          roles: roles || {}
        }
      };

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "admin save packages",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} updated the resources packages and role-based mappings.`
      );

      await userLog(db, req.session.userinfo.id, "Manage Packages", "Updated system default resources, plan packages list, and Discord role mappings.");

      return res.json({ success: true, message: "Packages and role mappings saved successfully!" });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write package updates to settings.json." });
    }
  });
};
