/**
 * |-| [- |_ | /\ ( ~|~ `/ |_
 *
 * Helix
 *
 * Admin management for the Invite-a-friend rewards system: base
 * coin reward, community Discord link, and milestone "invite plans".
 * @module admin_invite
 */

const fs = require("fs");
const crypto = require("crypto");
const settingsPath = "./settings.json";
const log = require("../misc/log");
const userLog = require("../misc/userLog");

module.exports.load = async function (app, db) {
  function isAdmin(req) {
    return req.session && req.session.pterodactyl && req.session.pterodactyl.root_admin === true;
  }

  // Save base invite settings: coins per invite + community Discord link
  app.post("/api/admin/invite/save", async (req, res) => {
    if (!isAdmin(req)) return res.status(403).json({ success: false, message: "Forbidden" });

    try {
      const { enabled, coins, discordLink } = req.body;
      const parsedCoins = parseFloat(coins);

      if (isNaN(parsedCoins) || parsedCoins < 0)
        return res.status(400).json({ success: false, message: "Please enter a valid, non-negative coin amount." });

      if (discordLink && !/^https?:\/\/(www\.)?discord(\.gg|\.com\/invite)\//i.test(discordLink))
        return res.status(400).json({ success: false, message: "Please enter a valid Discord invite link (discord.gg/... or discord.com/invite/...)." });

      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());
      if (!settings.invite) settings.invite = { plans: [] };
      settings.invite.enabled = enabled === true;
      settings.invite.coins = parsedCoins;
      settings.invite.discordLink = discordLink ? String(discordLink).trim() : "";
      if (!Array.isArray(settings.invite.plans)) settings.invite.plans = [];

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "admin save store",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} updated the invite system settings (enabled: \`${settings.invite.enabled}\`, coins: \`${parsedCoins}\`).`
      );
      await userLog(db, req.session.userinfo.id, "Manage Invite System", `Updated invite settings: ${settings.invite.enabled ? "enabled" : "disabled"}, ${parsedCoins} coins per invite.`);

      return res.json({ success: true, message: "Invite system settings saved successfully!" });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write configurations to settings.json." });
    }
  });

  // Add a milestone invite plan (e.g. "Invite 10 friends -> +200 bonus coins")
  app.post("/api/admin/invite/plans/add", async (req, res) => {
    if (!isAdmin(req)) return res.status(403).json({ success: false, message: "Forbidden" });

    try {
      let { title, requiredInvites, bonusCoins } = req.body;

      if (!title || !String(title).trim())
        return res.status(400).json({ success: false, message: "Please provide a plan title." });

      requiredInvites = parseInt(requiredInvites);
      bonusCoins = parseFloat(bonusCoins);

      if (isNaN(requiredInvites) || requiredInvites <= 0)
        return res.status(400).json({ success: false, message: "Required invites must be a positive whole number." });
      if (isNaN(bonusCoins) || bonusCoins <= 0)
        return res.status(400).json({ success: false, message: "Bonus coins must be a positive number." });

      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());
      if (!settings.invite) settings.invite = { enabled: true, coins: 50, discordLink: "", plans: [] };
      if (!Array.isArray(settings.invite.plans)) settings.invite.plans = [];

      const plan = {
        id: crypto.randomBytes(6).toString("hex"),
        title: String(title).trim().slice(0, 80),
        requiredInvites,
        bonusCoins,
      };

      settings.invite.plans.push(plan);
      settings.invite.plans.sort((a, b) => a.requiredInvites - b.requiredInvites);

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "admin save store",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} added the invite plan \`${plan.title}\` (${requiredInvites} invites -> ${bonusCoins} coins).`
      );
      await userLog(db, req.session.userinfo.id, "Manage Invite System", `Added invite plan "${plan.title}" (${requiredInvites} invites -> ${bonusCoins} bonus coins).`);

      return res.json({ success: true, message: "Invite plan added!", plan });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write configurations to settings.json." });
    }
  });

  // Edit an existing milestone invite plan
  app.post("/api/admin/invite/plans/edit", async (req, res) => {
    if (!isAdmin(req)) return res.status(403).json({ success: false, message: "Forbidden" });

    try {
      let { id, title, requiredInvites, bonusCoins } = req.body;

      if (!id) return res.status(400).json({ success: false, message: "Missing plan ID." });

      if (!title || !String(title).trim())
        return res.status(400).json({ success: false, message: "Please provide a plan title." });

      requiredInvites = parseInt(requiredInvites);
      bonusCoins = parseFloat(bonusCoins);

      if (isNaN(requiredInvites) || requiredInvites <= 0)
        return res.status(400).json({ success: false, message: "Required invites must be a positive whole number." });
      if (isNaN(bonusCoins) || bonusCoins <= 0)
        return res.status(400).json({ success: false, message: "Bonus coins must be a positive number." });

      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());
      if (!settings.invite || !Array.isArray(settings.invite.plans))
        return res.status(400).json({ success: false, message: "No invite plans configured." });

      const plan = settings.invite.plans.find((p) => p.id === id);
      if (!plan) return res.status(404).json({ success: false, message: "Plan not found." });

      plan.title = String(title).trim().slice(0, 80);
      plan.requiredInvites = requiredInvites;
      plan.bonusCoins = bonusCoins;

      settings.invite.plans.sort((a, b) => a.requiredInvites - b.requiredInvites);

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "admin save store",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} edited the invite plan \`${plan.title}\` (${requiredInvites} invites -> ${bonusCoins} coins).`
      );
      await userLog(db, req.session.userinfo.id, "Manage Invite System", `Edited invite plan "${plan.title}" (${requiredInvites} invites -> ${bonusCoins} bonus coins).`);

      return res.json({ success: true, message: "Invite plan updated!", plan });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write configurations to settings.json." });
    }
  });

  // Remove a milestone invite plan
  app.post("/api/admin/invite/plans/remove", async (req, res) => {
    if (!isAdmin(req)) return res.status(403).json({ success: false, message: "Forbidden" });

    try {
      const { id } = req.body;
      if (!id) return res.status(400).json({ success: false, message: "Missing plan ID." });

      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());
      if (!settings.invite || !Array.isArray(settings.invite.plans))
        return res.status(400).json({ success: false, message: "No invite plans configured." });

      const before = settings.invite.plans.length;
      settings.invite.plans = settings.invite.plans.filter((p) => p.id !== id);

      if (settings.invite.plans.length === before)
        return res.status(404).json({ success: false, message: "Plan not found." });

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "admin save store",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} removed an invite plan (ID \`${id}\`).`
      );
      await userLog(db, req.session.userinfo.id, "Manage Invite System", `Removed invite plan (ID ${id}).`);

      return res.json({ success: true, message: "Invite plan removed!" });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write configurations to settings.json." });
    }
  });
};
