const settings = require("../settings.json");
const log = require("../misc/log");

module.exports.load = async function (app, db) {
  // Helper to verify admin status
  function isAdmin(req) {
    return req.session && req.session.pterodactyl && req.session.pterodactyl.root_admin === true;
  }

  // Helper to verify login status
  function isLoggedIn(req) {
    return req.session && req.session.userinfo;
  }

  // Create Coupon
  app.post("/api/coupon/create", async (req, res) => {
    if (!isAdmin(req)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

    const { code, coins, ram, disk, cpu, servers, max_uses, expire_date } = req.body;

    if (!code || !code.match(/^[A-Za-z0-9_-]+$/)) {
      return res.status(400).json({ success: false, message: "Invalid coupon code format (alphanumeric, dashes, underscores only)." });
    }

    // Convert values safely
    const coinVal = parseFloat(coins) || 0;
    const ramVal = (parseFloat(ram) || 0) * 1024; // MB
    const diskVal = (parseFloat(disk) || 0) * 1024; // MB
    const cpuVal = (parseFloat(cpu) || 0) * 100; // %
    const serverVal = parseInt(servers) || 0;
    const maxUsesVal = parseInt(max_uses) || 0;

    if (coinVal < 0 || ramVal < 0 || diskVal < 0 || cpuVal < 0 || serverVal < 0 || maxUsesVal < 0) {
      return res.status(400).json({ success: false, message: "Reward and usage values must be positive." });
    }

    if (!coinVal && !ramVal && !diskVal && !cpuVal && !serverVal) {
      return res.status(400).json({ success: false, message: "Coupon must grant at least one reward resource." });
    }

    // Check if code already exists
    const existing = await db.get("coupon-" + code);
    if (existing) {
      return res.status(400).json({ success: false, message: "A coupon with this code already exists." });
    }

    const couponData = {
      code: code,
      coins: coinVal,
      ram: ramVal,
      disk: diskVal,
      cpu: cpuVal,
      servers: serverVal,
      max_uses: maxUsesVal,
      uses: 0,
      expire_date: expire_date ? new Date(expire_date).toISOString() : null,
      used_by: []
    };

    // Save coupon
    await db.set("coupon-" + code, couponData);

    // Update list index
    let list = await db.get("coupons-list") || [];
    if (!list.includes(code)) {
      list.push(code);
      await db.set("coupons-list", list);
    }

    log(
      "create coupon",
      `${req.session.userinfo.username}#${req.session.userinfo.discriminator} created coupon code \`${code}\`.`
    );

    return res.json({ success: true, message: "Coupon created successfully!" });
  });

  // Expire Coupon
  app.post("/api/coupon/expire", async (req, res) => {
    if (!isAdmin(req)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

    const { code } = req.body;
    if (!code) {
      return res.status(400).json({ success: false, message: "Missing coupon code." });
    }

    const coupon = await db.get("coupon-" + code);
    if (!coupon) {
      return res.status(404).json({ success: false, message: "Coupon not found." });
    }

    // Set expiration in the past
    coupon.expire_date = new Date(Date.now() - 1000).toISOString();
    await db.set("coupon-" + code, coupon);

    log(
      "expire coupon",
      `${req.session.userinfo.username}#${req.session.userinfo.discriminator} expired coupon code \`${code}\`.`
    );

    return res.json({ success: true, message: "Coupon expired successfully!" });
  });

  // Delete Coupon
  app.post("/api/coupon/delete", async (req, res) => {
    if (!isAdmin(req)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

    const { code } = req.body;
    if (!code) {
      return res.status(400).json({ success: false, message: "Missing coupon code." });
    }

    await db.delete("coupon-" + code);

    // Update list index
    let list = await db.get("coupons-list") || [];
    list = list.filter(c => c !== code);
    await db.set("coupons-list", list);

    log(
      "delete coupon",
      `${req.session.userinfo.username}#${req.session.userinfo.discriminator} deleted coupon code \`${code}\`.`
    );

    return res.json({ success: true, message: "Coupon deleted successfully!" });
  });

  // Redeem Coupon
  app.post("/api/coupon/redeem", async (req, res) => {
    if (!isLoggedIn(req)) {
      return res.status(401).json({ success: false, message: "You must be logged in to redeem a coupon." });
    }

    let { code } = req.body;
    if (!code) {
      return res.status(400).json({ success: false, message: "Please enter a coupon code." });
    }

    code = code.trim();

    const coupon = await db.get("coupon-" + code);
    if (!coupon) {
      return res.status(400).json({ success: false, message: "Invalid or non-existent coupon code." });
    }

    const userId = req.session.userinfo.id;

    // 1. Check expiration
    if (coupon.expire_date && new Date(coupon.expire_date) < new Date()) {
      return res.status(400).json({ success: false, message: "This coupon code has expired." });
    }

    // 2. Check maximum uses
    if (coupon.max_uses > 0 && (coupon.uses || 0) >= coupon.max_uses) {
      return res.status(400).json({ success: false, message: "This coupon code has reached its maximum usage limit." });
    }

    // 3. Check already redeemed by this user
    if (coupon.used_by && coupon.used_by.includes(userId)) {
      return res.status(400).json({ success: false, message: "You have already redeemed this coupon code." });
    }

    // Award rewards
    let usercoins = await db.get("coins-" + userId) || 0;
    let extra = await db.get("extra-" + userId) || { ram: 0, disk: 0, cpu: 0, servers: 0 };

    usercoins = usercoins + (coupon.coins || 0);
    extra.ram = extra.ram + (coupon.ram || 0);
    extra.disk = extra.disk + (coupon.disk || 0);
    extra.cpu = extra.cpu + (coupon.cpu || 0);
    extra.servers = extra.servers + (coupon.servers || 0);

    // Save user data
    await db.set("coins-" + userId, usercoins);
    await db.set("extra-" + userId, extra);

    // Update coupon stats
    coupon.uses = (coupon.uses || 0) + 1;
    if (!coupon.used_by) coupon.used_by = [];
    coupon.used_by.push(userId);
    await db.set("coupon-" + code, coupon);

    // Save redemption log for user
    let userRedeemed = await db.get("redeemed-coupons-" + userId) || [];
    userRedeemed.push({
      code: code,
      redeemed_at: new Date().toISOString(),
      rewards: {
        coins: coupon.coins,
        ram: coupon.ram,
        disk: coupon.disk,
        cpu: coupon.cpu,
        servers: coupon.servers
      }
    });
    await db.set("redeemed-coupons-" + userId, userRedeemed);

    log(
      "redeem coupon",
      `${req.session.userinfo.username}#${req.session.userinfo.discriminator} redeemed coupon code \`${code}\`.`
    );

    const userLog = require("../misc/userLog");
    await userLog(db, userId, "Coupon Redeemed", `Claimed coupon code ${code}.`);

    return res.json({
      success: true,
      message: `Coupon redeemed successfully! Received: ${coupon.coins > 0 ? coupon.coins + ' coins' : ''} ${coupon.ram > 0 ? (coupon.ram / 1024) + 'GB RAM' : ''}`
    });
  });
};
