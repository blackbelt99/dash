const settings = require("../settings.json");
const log = require("../misc/log");
const adminjs = require("./admin");
const userLog = require("../misc/userLog");

module.exports.load = async function (app, db) {
  // Helper to verify admin status
  function isAdmin(req) {
    return req.session && req.session.pterodactyl && req.session.pterodactyl.root_admin === true;
  }

  // Update user stats API endpoint
  app.post("/api/admin/users/update", async (req, res) => {
    if (!isAdmin(req)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

    const { id, coins, ram, disk, cpu, servers, package } = req.body;

    if (!id) {
      return res.status(400).json({ success: false, message: "Missing user ID." });
    }

    // Verify user exists in database
    const profile = await db.get("profile-" + id);
    if (!profile) {
      return res.status(404).json({ success: false, message: "User profile not found in database registry." });
    }

    try {
      // 1. Update Coins
      if (coins !== undefined && coins !== "") {
        const coinVal = parseFloat(coins);
        if (isNaN(coinVal) || coinVal < 0) {
          return res.status(400).json({ success: false, message: "Invalid coin balance value." });
        }
        await db.set("coins-" + id, coinVal);
      }

      // 2. Update Extra Resources
      let extra = {
        ram: (parseFloat(ram) || 0) * 1024, // Convert GB to MB
        disk: (parseFloat(disk) || 0) * 1024, // Convert GB to MB
        cpu: (parseFloat(cpu) || 0) * 100, // Convert Core units to %
        servers: parseInt(servers) || 0
      };

      if (extra.ram < 0 || extra.disk < 0 || extra.cpu < 0 || extra.servers < 0) {
        return res.status(400).json({ success: false, message: "Resource limits must be positive values." });
      }

      if (extra.ram === 0 && extra.disk === 0 && extra.cpu === 0 && extra.servers === 0) {
        await db.delete("extra-" + id);
      } else {
        await db.set("extra-" + id, extra);
      }

      // 3. Update Package Plan
      if (package) {
        if (package === "default") {
          await db.delete("package-" + id);
        } else {
          await db.set("package-" + id, package);
        }
      }

      // Run resource suspension validation check on panel
      await adminjs.suspend(id);

      // Log admin action to Discord
      log(
        "admin update user",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} updated user ${profile.username} (ID: ${id}) attributes:\n\`\`\`Coins: ${coins}\nRAM: ${ram} GB\nDisk: ${disk} GB\nCPU: ${cpu}%\nServers: ${servers}\nPackage: ${package}\`\`\``
      );

      // Log activity to user's local history logs
      await userLog(db, id, "Admin Modified Profile", `System Administrator ${req.session.userinfo.username} updated your balance, resources, or plan.`);

      return res.json({ success: true, message: "User account updated successfully!" });
    } catch (err) {
      console.error("Admin user update failed:", err);
      return res.status(500).json({ success: false, message: "An error occurred while updating the user attributes." });
    }
  });
};
