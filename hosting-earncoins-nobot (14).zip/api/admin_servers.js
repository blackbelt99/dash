const fetch = require("node-fetch");
const fs = require("fs");
const log = require("../misc/log");
const userLog = require("../misc/userLog");
const calculateRenewalCost = require("../misc/renewalCost");

module.exports.load = async function (app, db) {
  // Helper to verify admin status
  function isAdmin(req) {
    return req.session && req.session.pterodactyl && req.session.pterodactyl.root_admin === true;
  }

  // Helper to get active settings
  function getSettings() {
    return JSON.parse(fs.readFileSync("./settings.json").toString());
  }

  // Modify server details, limits, suspension and renewal date
  app.post("/api/admin/servers/modify", async (req, res) => {
    if (!isAdmin(req)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

    const { serverId, name, ram, disk, cpu, renewalEnabled, renewalDate, suspended } = req.body;
    if (!serverId || !name || typeof ram !== "number" || typeof disk !== "number" || typeof cpu !== "number") {
      return res.status(400).json({ success: false, message: "Missing required parameters." });
    }

    try {
      const settings = getSettings();

      // 1. Fetch server from Pterodactyl to get structural user & external_id metadata
      const pteroRes = await fetch(
        settings.pterodactyl.domain + "/api/application/servers/" + serverId,
        {
          headers: {
            Authorization: `Bearer ${settings.pterodactyl.key}`,
            Accept: "application/json"
          }
        }
      );
      if (!pteroRes.ok) {
        return res.status(400).json({ success: false, message: "Failed to retrieve server details from Pterodactyl panel." });
      }
      const srvData = await pteroRes.json();

      // 2. Update Details (Name) on Pterodactyl
      const detailRes = await fetch(
        settings.pterodactyl.domain + "/api/application/servers/" + serverId + "/details",
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${settings.pterodactyl.key}`,
            Accept: "application/json"
          },
          body: JSON.stringify({
            name: name,
            user: srvData.attributes.user,
            external_id: srvData.attributes.external_id
          })
        }
      );
      if (!detailRes.ok) {
        return res.status(400).json({ success: false, message: "Failed to update server name on Pterodactyl panel." });
      }

      // 3. Update Build Specs (RAM, Disk, CPU) on Pterodactyl
      const buildRes = await fetch(
        settings.pterodactyl.domain + "/api/application/servers/" + serverId + "/build",
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${settings.pterodactyl.key}`,
            Accept: "application/json"
          },
          body: JSON.stringify({
            limits: {
              memory: parseInt(ram),
              disk: parseInt(disk),
              cpu: parseInt(cpu),
              swap: srvData.attributes.limits.swap,
              io: srvData.attributes.limits.io
            },
            feature_limits: srvData.attributes.feature_limits,
            allocation: srvData.attributes.allocation
          })
        }
      );
      if (!buildRes.ok) {
        return res.status(400).json({ success: false, message: "Failed to update resource build specs on Pterodactyl panel." });
      }

      // 4. Update Suspension State on Pterodactyl if requested status is different
      const currentSuspended = srvData.attributes.suspended;
      if (currentSuspended !== suspended) {
        const action = suspended ? "suspend" : "unsuspend";
        const actionRes = await fetch(
          settings.pterodactyl.domain + "/api/application/servers/" + serverId + "/" + action,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${settings.pterodactyl.key}`
            }
          }
        );
        if (!actionRes.ok) {
          return res.status(400).json({ success: false, message: `Failed to ${action} server on Pterodactyl panel.` });
        }
      }

      // 5. Update local database renewal schedule
      if (renewalEnabled === false) {
        await db.delete("renewal-" + serverId);
      } else {
        let renewal = await db.get("renewal-" + serverId);
        const nextRenewalTime = parseInt(renewalDate) || (Date.now() + 7 * 24 * 60 * 60 * 1000);
        if (!renewal) {
          renewal = {
            nextRenewal: nextRenewalTime,
            suspendedAt: suspended ? Date.now() : null,
            ownerId: srvData.attributes.user, // Fallback to Pterodactyl user ID
            autoRenew: false
          };
        } else {
          renewal.nextRenewal = nextRenewalTime;
          renewal.suspendedAt = suspended ? Date.now() : null;
        }
        // Keep renewal cost in sync with the server's (possibly just-changed) specs
        renewal.cost = calculateRenewalCost(ram, disk, cpu, settings);
        await db.set("renewal-" + serverId, renewal);
      }

      log(
        "admin modify server",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} modified server \`${name}\` (ID: ${serverId}) specs & renewal schedule.`
      );

      await userLog(db, req.session.userinfo.id, "Admin Modify Server", `Modified server "${name}" limits and renewal schedule.`);

      return res.json({ success: true, message: "Server successfully updated on the database and Pterodactyl panel!" });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "An error occurred during server modification." });
    }
  });

  // Delete server
  app.post("/api/admin/servers/delete", async (req, res) => {
    if (!isAdmin(req)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

    const { serverId } = req.body;
    if (!serverId) {
      return res.status(400).json({ success: false, message: "Missing server ID." });
    }

    try {
      const settings = getSettings();

      // Delete from Pterodactyl
      const deleteRes = await fetch(
        settings.pterodactyl.domain + "/api/application/servers/" + serverId,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${settings.pterodactyl.key}`
          }
        }
      );
      if (!deleteRes.ok && deleteRes.status !== 404) {
        return res.status(400).json({ success: false, message: "Failed to delete server from Pterodactyl panel." });
      }

      // Delete local renewal DB key
      await db.delete("renewal-" + serverId);

      log(
        "admin delete server",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} deleted server ID: ${serverId} permanently.`
      );

      await userLog(db, req.session.userinfo.id, "Admin Delete Server", `Permanently deleted server ID: ${serverId}.`);

      return res.json({ success: true, message: "Server permanently deleted from database and Pterodactyl panel!" });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "An error occurred during server deletion." });
    }
  });
};
