/**
 * |-| [- |_ | /\ ( ~|~ `/ |_
 *
 * Helix
 *
 * One-click hide/unhide for dashboard features. Unlike the generic
 * settings-update endpoint, this only ever flips a single boolean and
 * never touches any other configuration (coin amounts, tokens, lists, etc).
 * @module admin_features
 */

const fs = require("fs");
const settingsPath = "./settings.json";
const log = require("../misc/log");
const userLog = require("../misc/userLog");

const FEATURE_MAP = {
  afk: (settings) => {
    if (!settings.api.afk) settings.api.afk = {};
    return settings.api.afk;
  },
  linkvertise: (settings) => {
    if (!settings.monetization) settings.monetization = {};
    if (!settings.monetization.linkvertise) settings.monetization.linkvertise = {};
    return settings.monetization.linkvertise;
  },
  invite: (settings) => {
    if (!settings.invite) settings.invite = {};
    return settings.invite;
  },
  boost: (settings) => {
    if (!settings.boost) settings.boost = {};
    return settings.boost;
  },
};

const FEATURE_LABELS = {
  afk: "AFK Earning",
  linkvertise: "Earn Coins (Links)",
  invite: "Invite Friends",
  boost: "Server Boost Reward",
};

module.exports.load = async function (app, db) {
  function isAdmin(req) {
    return req.session && req.session.pterodactyl && req.session.pterodactyl.root_admin === true;
  }

  app.post("/api/admin/features/toggle", async (req, res) => {
    if (!isAdmin(req)) return res.status(403).json({ success: false, message: "Forbidden" });

    try {
      const { feature, enabled } = req.body;
      const getTarget = FEATURE_MAP[feature];

      if (!getTarget) return res.status(400).json({ success: false, message: "Unknown feature." });

      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());
      const target = getTarget(settings);
      target.enabled = enabled === true;

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      const label = FEATURE_LABELS[feature] || feature;
      log(
        "admin save store",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} ${enabled ? "unhid" : "hid"} the "${label}" dashboard feature.`
      );
      await userLog(db, req.session.userinfo.id, "Manage Visibility", `${enabled ? "Unhid" : "Hid"} "${label}" on the dashboard.`);

      return res.json({ success: true, message: `${label} is now ${enabled ? "visible" : "hidden"}.` });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write configurations to settings.json." });
    }
  });
};
