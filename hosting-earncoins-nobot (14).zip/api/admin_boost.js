/**
 * |-| [- |_ | /\ ( ~|~ `/ |_
 *
 * Helix
 *
 * Admin management for the Server Boost rewards system: base coin
 * reward + an optional plan that's auto-assigned while a member is
 * boosting (and auto-reverted once they stop).
 * @module admin_boost
 */

const fs = require("fs");
const crypto = require("crypto");
const settingsPath = "./settings.json";
const log = require("../misc/log");
const userLog = require("../misc/userLog");

module.exports.load = async function (app, db) {
  function isAdmin(req) {
    return req.session && req.session.pterodactyl && req.session.pterodactyl.root_admin === true;
  }

  // Save boost reward settings: enabled, coins per boost, optional auto-plan
  app.post("/api/admin/boost/save", async (req, res) => {
    if (!isAdmin(req)) return res.status(403).json({ success: false, message: "Forbidden" });

    try {
      const { enabled, coins, planId } = req.body;
      const parsedCoins = parseFloat(coins);

      if (isNaN(parsedCoins) || parsedCoins < 0)
        return res.status(400).json({ success: false, message: "Please enter a valid, non-negative coin amount." });

      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());

      const cleanPlanId = planId ? String(planId).trim() : "";
      if (cleanPlanId && !settings.api.client.packages.list[cleanPlanId]) {
        return res.status(400).json({ success: false, message: `Unknown package "${cleanPlanId}".` });
      }

      if (!settings.boost) settings.boost = { plans: [] };
      settings.boost.enabled = enabled === true;
      settings.boost.coins = parsedCoins;
      settings.boost.planId = cleanPlanId;
      if (!Array.isArray(settings.boost.plans)) settings.boost.plans = [];

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "admin save boost",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} updated the boost reward settings (enabled: \`${settings.boost.enabled}\`, coins: \`${parsedCoins}\`, plan: \`${cleanPlanId || "(none)"}\`).`
      );
      await userLog(
        db,
        req.session.userinfo.id,
        "Manage Boost System",
        `Updated boost settings: ${settings.boost.enabled ? "enabled" : "disabled"}, ${parsedCoins} coins per boost${cleanPlanId ? `, auto-plan "${cleanPlanId}"` : ""}.`
      );

      return res.json({ success: true, message: "Boost reward settings saved successfully!" });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write configurations to settings.json." });
    }
  });

  // Add a milestone boost plan (e.g. "Boost 3x -> +1000 bonus coins")
  app.post("/api/admin/boost/plans/add", async (req, res) => {
    if (!isAdmin(req)) return res.status(403).json({ success: false, message: "Forbidden" });

    try {
      let { title, requiredBoosts, bonusCoins } = req.body;

      if (!title || !String(title).trim())
        return res.status(400).json({ success: false, message: "Please provide a plan title." });

      requiredBoosts = parseInt(requiredBoosts);
      bonusCoins = parseFloat(bonusCoins);

      if (isNaN(requiredBoosts) || requiredBoosts <= 0)
        return res.status(400).json({ success: false, message: "Required boosts must be a positive whole number." });
      if (isNaN(bonusCoins) || bonusCoins <= 0)
        return res.status(400).json({ success: false, message: "Bonus coins must be a positive number." });

      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());
      if (!settings.boost) settings.boost = { enabled: true, coins: 500, planId: "", plans: [] };
      if (!Array.isArray(settings.boost.plans)) settings.boost.plans = [];

      const plan = {
        id: crypto.randomBytes(6).toString("hex"),
        title: String(title).trim().slice(0, 80),
        requiredBoosts,
        bonusCoins,
      };

      settings.boost.plans.push(plan);
      settings.boost.plans.sort((a, b) => a.requiredBoosts - b.requiredBoosts);

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "admin save boost",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} added the boost plan \`${plan.title}\` (${requiredBoosts} boosts -> ${bonusCoins} coins).`
      );
      await userLog(db, req.session.userinfo.id, "Manage Boost System", `Added boost plan "${plan.title}" (${requiredBoosts} boosts -> ${bonusCoins} bonus coins).`);

      return res.json({ success: true, message: "Boost plan added!", plan });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write configurations to settings.json." });
    }
  });

  // Edit an existing milestone boost plan
  app.post("/api/admin/boost/plans/edit", async (req, res) => {
    if (!isAdmin(req)) return res.status(403).json({ success: false, message: "Forbidden" });

    try {
      let { id, title, requiredBoosts, bonusCoins } = req.body;

      if (!id) return res.status(400).json({ success: false, message: "Missing plan ID." });

      if (!title || !String(title).trim())
        return res.status(400).json({ success: false, message: "Please provide a plan title." });

      requiredBoosts = parseInt(requiredBoosts);
      bonusCoins = parseFloat(bonusCoins);

      if (isNaN(requiredBoosts) || requiredBoosts <= 0)
        return res.status(400).json({ success: false, message: "Required boosts must be a positive whole number." });
      if (isNaN(bonusCoins) || bonusCoins <= 0)
        return res.status(400).json({ success: false, message: "Bonus coins must be a positive number." });

      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());
      if (!settings.boost || !Array.isArray(settings.boost.plans))
        return res.status(400).json({ success: false, message: "No boost plans configured." });

      const plan = settings.boost.plans.find((p) => p.id === id);
      if (!plan) return res.status(404).json({ success: false, message: "Plan not found." });

      plan.title = String(title).trim().slice(0, 80);
      plan.requiredBoosts = requiredBoosts;
      plan.bonusCoins = bonusCoins;

      settings.boost.plans.sort((a, b) => a.requiredBoosts - b.requiredBoosts);

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "admin save boost",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} edited the boost plan \`${plan.title}\` (${requiredBoosts} boosts -> ${bonusCoins} coins).`
      );
      await userLog(db, req.session.userinfo.id, "Manage Boost System", `Edited boost plan "${plan.title}" (${requiredBoosts} boosts -> ${bonusCoins} bonus coins).`);

      return res.json({ success: true, message: "Boost plan updated!", plan });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write configurations to settings.json." });
    }
  });

  // Remove a milestone boost plan
  app.post("/api/admin/boost/plans/remove", async (req, res) => {
    if (!isAdmin(req)) return res.status(403).json({ success: false, message: "Forbidden" });

    try {
      const { id } = req.body;
      if (!id) return res.status(400).json({ success: false, message: "Missing plan ID." });

      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());
      if (!settings.boost || !Array.isArray(settings.boost.plans))
        return res.status(400).json({ success: false, message: "No boost plans configured." });

      const before = settings.boost.plans.length;
      settings.boost.plans = settings.boost.plans.filter((p) => p.id !== id);

      if (settings.boost.plans.length === before)
        return res.status(404).json({ success: false, message: "Plan not found." });

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "admin save boost",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} removed a boost plan (ID \`${id}\`).`
      );
      await userLog(db, req.session.userinfo.id, "Manage Boost System", `Removed boost plan (ID ${id}).`);

      return res.json({ success: true, message: "Boost plan removed!" });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write configurations to settings.json." });
    }
  });
};
