const fetch = require("node-fetch");
const fs = require("fs");
const log = require("../misc/log");
const userLog = require("../misc/userLog");
const calculateRenewalCost = require("../misc/renewalCost");

module.exports.load = async function (app, db) {
  // Helper to get active settings
  function getSettings() {
    return JSON.parse(fs.readFileSync("./settings.json").toString());
  }

  // Helper to verify if user owns a specific server ID
  function userOwnsServer(req, serverId) {
    if (!req.session.pterodactyl || !req.session.pterodactyl.relationships || !req.session.pterodactyl.relationships.servers) {
      return false;
    }
    const serversList = req.session.pterodactyl.relationships.servers.data;
    return serversList.some(srv => srv.attributes.id == serverId);
  }

  // Get Renewal metadata for a server
  app.get("/api/server/renewal-info", async (req, res) => {
    if (!req.session.pterodactyl) {
      return res.status(401).json({ success: false, message: "Unauthorized" });
    }

    const currentSettings = getSettings();
    if (!currentSettings.api.renewal || currentSettings.api.renewal.enabled !== true) {
      return res.json({ success: false, message: "Server renewal system is globally disabled." });
    }

    const serverId = req.query.id;
    if (!serverId) {
      return res.status(400).json({ success: false, message: "Missing server ID parameter." });
    }

    if (!userOwnsServer(req, serverId)) {
      return res.status(403).json({ success: false, message: "Access denied: you do not own this server." });
    }

    try {
      const currentSettings = getSettings();
      let renewal = await db.get("renewal-" + serverId);

      if (!renewal) {
        return res.json({
          success: true,
          required: false
        });
      }

      // Backfill cost for renewal records seeded before per-server pricing existed
      if (typeof renewal.cost !== "number") {
        const srvObj = req.session.pterodactyl.relationships.servers.data.find(srv => srv.attributes.id == serverId);
        const limits = (srvObj && srvObj.attributes.limits) || {};
        renewal.cost = calculateRenewalCost(limits.memory, limits.disk, limits.cpu, currentSettings);
        await db.set("renewal-" + serverId, renewal);
      }

      return res.json({
        success: true,
        required: true,
        nextRenewal: renewal.nextRenewal,
        suspendedAt: renewal.suspendedAt,
        cost: renewal.cost
      });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to fetch renewal metadata." });
    }
  });

  // Renew a server
  app.post("/api/server/renew", async (req, res) => {
    if (!req.session.pterodactyl) {
      return res.status(401).json({ success: false, message: "Unauthorized" });
    }

    const currentSettings = getSettings();
    if (!currentSettings.api.renewal || currentSettings.api.renewal.enabled !== true) {
      return res.json({ success: false, message: "Server renewal system is globally disabled." });
    }

    const { serverId } = req.body;
    if (!serverId) {
      return res.status(400).json({ success: false, message: "Missing server ID." });
    }

    if (!userOwnsServer(req, serverId)) {
      return res.status(403).json({ success: false, message: "Access denied: you do not own this server." });
    }

    try {
      const currentSettings = getSettings();
      const renewalInterval = (currentSettings.api.renewal && currentSettings.api.renewal.interval) || 7;

      // Check user coins
      const userId = req.session.userinfo.id;
      let userCoins = await db.get("coins-" + userId);
      if (typeof userCoins !== "number") userCoins = 0;

      let renewal = await db.get("renewal-" + serverId);
      if (!renewal) {
        renewal = {
          nextRenewal: Date.now(),
          suspendedAt: null,
          ownerId: userId,
          autoRenew: false
        };
      }

      // Cost is proportional to this server's specs (RAM/Disk/CPU coin-store price).
      // Backfill it if this renewal record predates per-server pricing.
      if (typeof renewal.cost !== "number") {
        const srvObj = req.session.pterodactyl.relationships.servers.data.find(srv => srv.attributes.id == serverId);
        const limits = (srvObj && srvObj.attributes.limits) || {};
        renewal.cost = calculateRenewalCost(limits.memory, limits.disk, limits.cpu, currentSettings);
      }
      const renewalCost = renewal.cost;

      if (userCoins < renewalCost) {
        return res.json({
          success: false,
          message: `Insufficient coins. You need ${renewalCost} coins to renew, but only have ${userCoins.toFixed(2)} coins.`
        });
      }

      // Extend renewal (add renewalInterval days to the current remaining time or from now if already expired)
      const baseTime = Math.max(renewal.nextRenewal, Date.now());
      renewal.nextRenewal = baseTime + renewalInterval * 24 * 60 * 60 * 1000;
      renewal.suspendedAt = null;

      // Save to database
      await db.set("renewal-" + serverId, renewal);

      // Deduct coins
      userCoins -= renewalCost;
      await db.set("coins-" + userId, userCoins);

      // Instantly unsuspend on Pterodactyl to avoid lag
      await fetch(
        currentSettings.pterodactyl.domain + "/api/application/servers/" + serverId + "/unsuspend",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${currentSettings.pterodactyl.key}`
          }
        }
      );

      // Find server name from session list
      const srvObj = req.session.pterodactyl.relationships.servers.data.find(srv => srv.attributes.id == serverId);
      const serverName = srvObj ? srvObj.attributes.name : "Server";

      log(
        "renewed server",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} renewed server \`${serverName}\` (ID: ${serverId}) for 7 days costing ${renewalCost} coins.`
      );

      await userLog(db, userId, "Renew Server", `Renewed server "${serverName}" for 7 days (Cost: ${renewalCost} coins).`);

      return res.json({
        success: true,
        message: "Server successfully renewed for 7 days!",
        newCoins: userCoins,
        nextRenewal: renewal.nextRenewal
      });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "An error occurred during server renewal." });
    }
  });

  // Toggle Auto-Renew
  app.post("/api/server/toggle-autorenew", async (req, res) => {
    if (!req.session.pterodactyl) {
      return res.status(401).json({ success: false, message: "Unauthorized" });
    }

    const currentSettings = getSettings();
    if (!currentSettings.api.renewal || currentSettings.api.renewal.enabled !== true) {
      return res.json({ success: false, message: "Server renewal system is globally disabled." });
    }

    const { serverId, autoRenew } = req.body;
    if (!serverId || typeof autoRenew !== "boolean") {
      return res.status(400).json({ success: false, message: "Missing required parameters." });
    }

    if (!userOwnsServer(req, serverId)) {
      return res.status(403).json({ success: false, message: "Access denied: you do not own this server." });
    }

    try {
      let renewal = await db.get("renewal-" + serverId);
      if (!renewal) {
        renewal = {
          nextRenewal: Date.now() + 7 * 24 * 60 * 60 * 1000,
          suspendedAt: null
        };
      }

      renewal.autoRenew = autoRenew;
      renewal.ownerId = req.session.userinfo.id; // Guarantee ownerId is cached

      await db.set("renewal-" + serverId, renewal);

      const srvObj = req.session.pterodactyl.relationships.servers.data.find(srv => srv.attributes.id == serverId);
      const serverName = srvObj ? srvObj.attributes.name : "Server";

      await userLog(db, req.session.userinfo.id, "Toggle Auto-Renew", `${autoRenew ? "Enabled" : "Disabled"} Auto-Renew for server "${serverName}".`);

      return res.json({ success: true, message: `Auto-Renew successfully ${autoRenew ? 'enabled' : 'disabled'}!`, autoRenew });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "An error occurred while toggling auto-renew." });
    }
  });
};
