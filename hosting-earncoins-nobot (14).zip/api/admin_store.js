const fs = require("fs");
const settingsPath = "./settings.json";
const log = require("../misc/log");
const userLog = require("../misc/userLog");

module.exports.load = async function (app, db) {
  // Helper to verify admin status
  function isAdmin(req) {
    return req.session && req.session.pterodactyl && req.session.pterodactyl.root_admin === true;
  }

  // Save Store and AFK settings
  app.post("/api/admin/store/save", async (req, res) => {
    if (!isAdmin(req)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

    const {
      storeEnabled,
      ramCost,
      ramPer,
      diskCost,
      diskPer,
      cpuCost,
      cpuPer,
      serversCost,
      serversPer,
      afkEnabled,
      afkEvery,
      afkCoins,
      linkvertiseEnabled,
      linkvertiseToken,
      linkvertiseUserid,
      linkvertiseCoins,
      linkvertiseCooldown,
      renewalEnabled,
      renewalInterval,
      renewalGracePeriod,
      renewalCost
    } = req.body;

    try {
      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());
      
      // Update store parameters
      settings.api.client.coins.store = {
        enabled: storeEnabled === true,
        ram: {
          cost: parseInt(ramCost) || 300,
          per: parseInt(ramPer) || 1024
        },
        disk: {
          cost: parseInt(diskCost) || 200,
          per: parseInt(diskPer) || 5120
        },
        cpu: {
          cost: parseInt(cpuCost) || 350,
          per: parseInt(cpuPer) || 100
        },
        servers: {
          cost: parseInt(serversCost) || 100,
          per: parseInt(serversPer) || 2
        }
      };

      // Update AFK parameters
      settings.api.afk.enabled = afkEnabled === true;
      settings.api.afk.every = parseInt(afkEvery) || 60;
      settings.api.afk.coins = parseFloat(afkCoins) || 1.0;

      // Update Linkvertise parameters
      if (!settings.monetization) {
        settings.monetization = {};
      }
      settings.monetization.linkvertise = {
        enabled: linkvertiseEnabled === true,
        token: linkvertiseToken || "",
        userid: linkvertiseUserid || "",
        coins: parseFloat(linkvertiseCoins) || 5.0,
        cooldown: parseInt(linkvertiseCooldown) || 3600
      };

      // Update Renewal parameters
      if (!settings.api.renewal) {
        settings.api.renewal = {};
      }
      settings.api.renewal = {
        enabled: renewalEnabled === true,
        cost: parseInt(renewalCost) || 20,
        interval: parseInt(renewalInterval) || 7,
        gracePeriod: parseInt(renewalGracePeriod) || 3
      };

      // Ensure backwards compatibility with other elements reading client.coins.renewalCost
      settings.api.client.coins.renewalCost = parseInt(renewalCost) || 20;

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "admin save store",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} updated the store costs, AFK, and Linkvertise monetization configuration.`
      );

      await userLog(db, req.session.userinfo.id, "Manage Store", "Updated resource store costs, AFK farming intervals, and Linkvertise earning settings.");

      return res.json({ success: true, message: "Store, AFK & Earning configurations saved successfully!" });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write configurations to settings.json." });
    }
  });
};
