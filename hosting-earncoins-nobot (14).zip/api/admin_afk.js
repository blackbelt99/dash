/**
 * |-| [- |_ | /\ ( ~|~ `/ |_
 *
 * Helix
 *
 * Dedicated admin management for the AFK earning system.
 * @module admin_afk
 */

const fs = require("fs");
const settingsPath = "./settings.json";
const log = require("../misc/log");
const userLog = require("../misc/userLog");

module.exports.load = async function (app, db) {
  function isAdmin(req) {
    return req.session && req.session.pterodactyl && req.session.pterodactyl.root_admin === true;
  }

  app.post("/api/admin/afk/save", async (req, res) => {
    if (!isAdmin(req)) return res.status(403).json({ success: false, message: "Forbidden" });

    try {
      const { enabled, every, coins } = req.body;
      const parsedEvery = parseInt(every);
      const parsedCoins = parseFloat(coins);

      if (isNaN(parsedEvery) || parsedEvery <= 0)
        return res.status(400).json({ success: false, message: "Interval must be a positive number of seconds." });
      if (isNaN(parsedCoins) || parsedCoins <= 0)
        return res.status(400).json({ success: false, message: "Coin reward must be a positive number." });

      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());
      if (!settings.api.afk) settings.api.afk = {};
      settings.api.afk.enabled = enabled === true;
      settings.api.afk.every = parsedEvery;
      settings.api.afk.coins = parsedCoins;

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "admin save store",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} ${enabled ? "unhid" : "hid"} the AFK page and updated its earning rate (${parsedCoins} coins / ${parsedEvery}s).`
      );
      await userLog(db, req.session.userinfo.id, "Manage AFK System", `${enabled ? "Unhid" : "Hid"} AFK earning, set to ${parsedCoins} coins every ${parsedEvery}s.`);

      return res.json({ success: true, message: "AFK settings saved successfully!" });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write configurations to settings.json." });
    }
  });
};
