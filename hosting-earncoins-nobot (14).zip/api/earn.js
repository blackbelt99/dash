const settings = require("../settings.json");
const fetch = require("node-fetch");

module.exports.load = async function (app, db) {
  // Callback endpoint for Linkvertise redirects
  app.get("/earn/linkvertise/callback", async (req, res) => {
    let newsettings = require("../settings.json");
    if (!newsettings.monetization || !newsettings.monetization.linkvertise || !newsettings.monetization.linkvertise.enabled) {
      return res.redirect("/earn?err=disabled");
    }

    const userId = req.query.user;
    const hash = req.query.hash;

    if (!userId || !hash) {
      return res.redirect("/earn?err=missing_data");
    }

    try {
      // 1. Verify cooldown
      const cooldownTime = await db.get("linkvertise-cooldown-" + userId) || 0;
      if (cooldownTime > Date.now()) {
        return res.redirect("/earn?err=cooldown");
      }

      // 2. Query Linkvertise API for validation
      const response = await fetch("https://publisher.linkvertise.com/api/v1/anti_bypassing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token: newsettings.monetization.linkvertise.token,
          hash: hash
        })
      });

      let result;
      const text = await response.text();
      try {
        result = JSON.parse(text);
      } catch (e) {
        result = text;
      }

      if (result === "true" || result === true || (result && (result.status === true || result.status === "true"))) {
        // Success! Award coins
        let usercoins = await db.get("coins-" + userId) || 0;
        usercoins = usercoins + newsettings.monetization.linkvertise.coins;
        await db.set("coins-" + userId, usercoins);

        // Set cooldown timestamp
        const cooldownDuration = newsettings.monetization.linkvertise.cooldown || 3600;
        await db.set("linkvertise-cooldown-" + userId, Date.now() + cooldownDuration * 1000);

        const userLog = require("../misc/userLog");
        await userLog(db, userId, "Linkvertise Coins", `Earned ${newsettings.monetization.linkvertise.coins.toFixed(2)} coins.`);

        return res.redirect("/earn?err=none");
      } else {
        console.error("Linkvertise verification failed:", text);
        return res.redirect("/earn?err=verification_failed");
      }
    } catch (err) {
      console.error("Linkvertise callback error:", err);
      return res.redirect("/earn?err=error");
    }
  });
};
