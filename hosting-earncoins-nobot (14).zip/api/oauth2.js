/**
 * |-| [- |_ | /\ ( ~|~ `/ |_
 *
 * Helix
 *
 * This is for the horrible OAuth2 system that shouldn't be used in production (but it is).
 * @module oauth2
*/

"use strict";

const settings = require("../settings.json");
const demoMode = require("../misc/demoMode");

if (settings.api.client.oauth2.link.slice(-1) == "/")
  settings.api.client.oauth2.link = settings.api.client.oauth2.link.slice(
    0,
    -1
  );

if (settings.api.client.oauth2.callbackpath.slice(0, 1) !== "/")
  settings.api.client.oauth2.callbackpath =
    "/" + settings.api.client.oauth2.callbackpath;

if (!demoMode.isDemoMode() && settings.pterodactyl.domain.slice(-1) == "/")
  settings.pterodactyl.domain = settings.pterodactyl.domain.slice(0, -1);

const fetch = require("node-fetch");

const indexjs = require("../app.js");
const log = require("../misc/log");

const fs = require("fs");
const { renderFile } = require("ejs");
// 05/2023: removed - no one used it so this should be removed from oauth
const vpnCheck = require("../misc/vpnCheck");

module.exports.load = async function (app, db) {
  app.get("/login", async (req, res) => {
    if (req.query.redirect) req.session.redirect = "/" + req.query.redirect;
    if (req.query.ref && /^[0-9]{15,25}$/.test(req.query.ref)) req.session.ref = req.query.ref;
    let newsettings = JSON.parse(fs.readFileSync("./settings.json"));
    res.redirect(
      `https://discord.com/api/oauth2/authorize?client_id=${
        settings.api.client.oauth2.id
      }&redirect_uri=${encodeURIComponent(
        settings.api.client.oauth2.link +
          settings.api.client.oauth2.callbackpath
      )}&response_type=code&scope=identify%20email${
        newsettings.api.client.bot.joinguild.enabled == true
          ? "%20guilds.join"
          : ""
      }${
        settings.api.client.oauth2.prompt == false
          ? "&prompt=none"
          : req.query.prompt
          ? req.query.prompt == "none"
            ? "&prompt=none"
            : ""
          : ""
      }`
    );
  });

  app.get("/logout", (req, res) => {
    let theme = indexjs.get(req);
    req.session.destroy(() => {
      return res.redirect(
        theme.settings.redirect.logout ? theme.settings.redirect.logout : "/"
      );
    });
  });

  app.get(settings.api.client.oauth2.callbackpath, async (req, res) => {
    if (!req.query.code) return res.redirect(`/login`);
    res.send(`
    <!doctype html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://cdn.tailwindcss.com"></script>
        <title>Please wait...</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <style>
          :root {
            --font-outfit: 'Plus Jakarta Sans', sans-serif;
            --font-inter: 'Inter', sans-serif;
          }
          body {
            font-family: var(--font-inter);
            background-color: #020617;
            color: #f8fafc;
            margin: 0;
            padding: 0;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            position: relative;
          }
          .bg-mesh {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
              linear-gradient(rgba(255, 255, 255, 0.015) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255, 255, 255, 0.015) 1px, transparent 1px);
            background-size: 50px 50px;
            pointer-events: none;
            z-index: 1;
          }
          .noise-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='0.02'/%3E%3C/svg%3E");
            pointer-events: none;
            z-index: 9999;
          }
          .glow-sphere {
            position: absolute;
            border-radius: 50%;
            filter: blur(140px);
            z-index: 0;
            pointer-events: none;
            opacity: 0.55;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 60vw;
            height: 60vw;
            background: radial-gradient(circle, rgba(59, 130, 246, 0.3) 0%, rgba(30, 58, 138, 0.05) 75%, transparent 100%);
          }
          .animate-spin-slow {
            animation: spin-slow 8s linear infinite;
          }
          @keyframes spin-slow {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
        </style>
    </head>
    <body>
        <div class="noise-overlay"></div>
        <div class="bg-mesh"></div>
        <div class="glow-sphere"></div>

        <div class="z-10 flex flex-col items-center space-y-4">
          <div class="h-16 w-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-blue-400 p-[2px] flex items-center justify-center shadow-lg shadow-blue-500/20">
            <div class="h-full w-full rounded-[14px] bg-slate-950 flex items-center justify-center overflow-hidden">
              <img class="h-10 w-10 object-contain animate-spin-slow" src="../assets/favicon.png" alt="Logo">
            </div>
          </div>
          <h2 class="text-white font-bold text-lg tracking-wider uppercase animate-pulse" style="font-family: var(--font-outfit);">Logging in...</h2>
          <p class="text-slate-400 text-xs font-light tracking-wide animate-pulse">Authenticating your profile. Please wait.</p>
        </div>
    </body>
    </html>

    <script type="text/javascript" defer>
      history.pushState('/login', 'Logging in...', '/login')
      window.location.replace('/submitlogin?code=${encodeURIComponent(
        req.query.code.replace(/'/g, "")
      )}')
    </script>
    `);
  });

  app.get(`/submitlogin`, async (req, res) => {
    let customredirect = req.session.redirect;
    delete req.session.redirect;
    if (!req.query.code) return res.send("Missing code.");

    const newsettings = require("../settings.json");

    let ip =
      newsettings.api.client.oauth2.ip["trust x-forwarded-for"] == true
        ? req.headers["x-forwarded-for"] || req.connection.remoteAddress
        : req.connection.remoteAddress;
    ip = (ip ? ip : "::1")
      .replace(/::1/g, "::ffff:127.0.0.1")
      .replace(/^.*:/, "");
    if (
      newsettings.antivpn &&
      newsettings.antivpn.status &&
      ip !== "127.0.0.1" &&
      !newsettings.antivpn.whitelistedIPs.includes(ip)
    ) {
      const vpn = await vpnCheck(newsettings.antivpn.APIKey, db, ip, res);
      if (vpn) return;
    }

    let json = await fetch("https://discord.com/api/oauth2/token", {
      method: "post",
      body:
        "client_id=" +
        settings.api.client.oauth2.id +
        "&client_secret=" +
        settings.api.client.oauth2.secret +
        "&grant_type=authorization_code&code=" +
        encodeURIComponent(req.query.code) +
        "&redirect_uri=" +
        encodeURIComponent(
          settings.api.client.oauth2.link +
            settings.api.client.oauth2.callbackpath
        ),
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    });
    if (json.ok == true) {
      let codeinfo = JSON.parse(await json.text());
      let scopes = codeinfo.scope;
      let missingscopes = [];

      if (scopes.replace(/identify/g, "") == scopes)
        missingscopes.push("identify");
      if (scopes.replace(/email/g, "") == scopes) missingscopes.push("email");
      if (newsettings.api.client.bot.joinguild.enabled == true)
        if (scopes.replace(/guilds.join/g, "") == scopes)
          missingscopes.push("guilds.join");
      if (missingscopes.length !== 0)
        return res.send("Missing scopes: " + missingscopes.join(", "));
      let userjson = await fetch("https://discord.com/api/users/@me", {
        method: "get",
        headers: {
          Authorization: `Bearer ${codeinfo.access_token}`,
        },
      });
      let userinfo = JSON.parse(await userjson.text());

      if (settings.whitelist.status) {
        if (!settings.whitelist.users.includes(userinfo.id))
          return res.send("Service is under maintenance.");
      }

      let guildsjson = await fetch("https://discord.com/api/users/@me/guilds", {
        method: "get",
        headers: {
          Authorization: `Bearer ${codeinfo.access_token}`,
        },
      });
      let guildsinfo = await guildsjson.json();
      if (userinfo.verified == true) {
        if (newsettings.api.client.oauth2.ip.block.includes(ip))
          return res.send(
            "You could not sign in, because your IP has been blocked from signing in."
          );

        if (
          newsettings.api.client.oauth2.ip["duplicate check"] == true &&
          ip !== "127.0.0.1"
        ) {
          const ipuser = await db.get(`ipuser-${ip}`);
          if (ipuser && ipuser !== userinfo.id) {
            renderFile(
              `./themes/${newsettings.defaulttheme}/alerts/alt.ejs`,
              {
                settings: newsettings,
                db,
                extra: { home: { name: "VPN Detected" } },
              },
              null,
              (err, str) => {
                if (err)
                  return res.send(
                    'Another account on your IP has been detected, there can only be one account per IP. Think this is a mistake? <a href="https://discord.gg/halexnodes" target="_blank">Join our discord.</a>'
                  );
                res.status(200);
                res.send(str);
              }
            );
            return;
          } else if (!ipuser) {
            await db.set(`ipuser-${ip}`, userinfo.id);
          }
        }

        if (newsettings.api.client.bot.joinguild.enabled == true) {
          if (typeof newsettings.api.client.bot.joinguild.guildid == "string") {
            await fetch(
              `https://discord.com/api/guilds/${newsettings.api.client.bot.joinguild.guildid}/members/${userinfo.id}`,
              {
                method: "put",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bot ${newsettings.api.client.bot.token}`,
                },
                body: JSON.stringify({
                  access_token: codeinfo.access_token,
                }),
              }
            );
          } else if (
            typeof newsettings.api.client.bot.joinguild.guildid == "object"
          ) {
            if (Array.isArray(newsettings.api.client.bot.joinguild.guildid)) {
              for (let guild of newsettings.api.client.bot.joinguild.guildid) {
                await fetch(
                  `https://discord.com/api/guilds/${guild}/members/${userinfo.id}`,
                  {
                    method: "put",
                    headers: {
                      "Content-Type": "application/json",
                      Authorization: `Bot ${newsettings.api.client.bot.token}`,
                    },
                    body: JSON.stringify({
                      access_token: codeinfo.access_token,
                    }),
                  }
                );
              }
            } else {
              return res.send(
                "api.client.bot.joinguild.guildid is not an array nor a string."
              );
            }
          } else {
            return res.send(
              "api.client.bot.joinguild.guildid is not an array nor a string."
            );
          }
        }

        //give role on login
        if (newsettings.api.client.bot.giverole.enabled == true) {
          if (
            typeof newsettings.api.client.bot.giverole.guildid == "string" &&
            typeof newsettings.api.client.bot.giverole.roleid == "string"
          ) {
            await fetch(
              `https://discord.com/api/guilds/${newsettings.api.client.bot.giverole.guildid}/members/${userinfo.id}/roles/${newsettings.api.client.bot.giverole.roleid}`,
              {
                method: "put",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bot ${newsettings.api.client.bot.token}`,
                },
              }
            );
          } else {
            return res.send(
              "api.client.bot.giverole.guildid or roleid is not a string."
            );
          }
        }

        // Applying role packages
        if (newsettings.api.client.packages.rolePackages.roles) {
          const member = await fetch(
            `https://discord.com/api/v9/guilds/${newsettings.api.client.packages.rolePackages.roleServer}/members/${userinfo.id}`,
            {
              headers: {
                Authorization: `Bot ${newsettings.api.client.bot.token}`,
              },
            }
          );
          const memberinfo = await member.json();
          if (memberinfo.user) {
            const currentpackage = await db.get(`package-${userinfo.id}`);
            if (
              Object.values(
                newsettings.api.client.packages.rolePackages.roles
              ).includes(currentpackage)
            ) {
              for (const rolePackage of Object.keys(
                newsettings.api.client.packages.rolePackages.roles
              )) {
                if (
                  newsettings.api.client.packages.rolePackages.roles[
                    rolePackage
                  ] === currentpackage
                ) {
                  if (!memberinfo.roles.includes(rolePackage)) {
                    await db.set(
                      `package-${userinfo.id}`,
                      newsettings.api.client.packages.default
                    );
                  }
                }
              }
            }
            for (const role of memberinfo.roles) {
              if (newsettings.api.client.packages.rolePackages.roles[role]) {
                await db.set(
                  `package-${userinfo.id}`,
                  newsettings.api.client.packages.rolePackages.roles[role]
                );
              }
            }
          }
        }

        if (!(await db.get("users-" + userinfo.id))) {
          if (newsettings.api.client.allow.newusers == true) {
            // Demo Mode: Skip Pterodactyl account creation
            if (demoMode.isDemoMode()) {
              let mockUser = demoMode.getMockPterodactylUser(userinfo);
              let userids = (await db.get("users")) ? await db.get("users") : [];
              userids.push(mockUser.id);
              await db.set("users", userids);
              await db.set("users-" + userinfo.id, mockUser.id);
              req.session.pterodactyl = mockUser;
              req.session.newaccount = true;
              req.session.password = "demo-password-123";
              log(
                "signup",
                `${userinfo.username}#${userinfo.discriminator} logged in to the dashboard for the first time! (Demo Mode)`
              );
            } else {
              // Normal Pterodactyl account creation
              let genpassword = null;
              if (newsettings.api.client.passwordgenerator.signup == true)
                genpassword = makeid(
                  newsettings.api.client.passwordgenerator["length"]
                );
              let accountjson = await fetch(
                settings.pterodactyl.domain + "/api/application/users",
                {
                  method: "post",
                  headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${settings.pterodactyl.key}`,
                  },
                  body: JSON.stringify({
                    username: userinfo.id,
                    email: userinfo.email,
                    first_name: userinfo.username,
                    last_name: "#" + userinfo.discriminator,
                    password: genpassword,
                  }),
                }
              );
              if ((await accountjson.status) == 201) {
                let accountinfo = JSON.parse(await accountjson.text());
                let userids = (await db.get("users"))
                  ? await db.get("users")
                  : [];
                userids.push(accountinfo.attributes.id);
                await db.set("users", userids);
                await db.set("users-" + userinfo.id, accountinfo.attributes.id);
                req.session.newaccount = true;
                req.session.password = genpassword;
              } else {
                let accountlistjson = await fetch(
                  settings.pterodactyl.domain +
                    "/api/application/users?include=servers&filter[email]=" +
                    encodeURIComponent(userinfo.email),
                  {
                    method: "get",
                    headers: {
                      "Content-Type": "application/json",
                      Authorization: `Bearer ${settings.pterodactyl.key}`,
                    },
                  }
                );
                let accountlist = await accountlistjson.json();
                let user = accountlist.data.filter(
                  (acc) => acc.attributes.email == userinfo.email
                );
                if (user.length == 1) {
                  let userid = user[0].attributes.id;
                  let userids = (await db.get("users"))
                    ? await db.get("users")
                    : [];
                  if (userids.filter((id) => id == userid).length == 0) {
                    userids.push(userid);
                    await db.set("users", userids);
                    await db.set("users-" + userinfo.id, userid);
                    req.session.pterodactyl = user[0].attributes;
                  } else {
                    return res.send(
                      "We have detected an account with your Discord email on it but the user id has already been claimed on another Discord account."
                    );
                  }
                } else {
                  return res.send(
                    "An error has occured when attempting to create your account."
                  );
                }
              }
              log(
                "signup",
                `${userinfo.username}#${userinfo.discriminator} logged in to the dashboard for the first time!`
              );
            }
          } else {
            return res.send("New users cannot signup currently.");
          }
        }

        // Invite-a-friend rewards: credit the referrer once, only for brand new accounts
        if (req.session.newaccount && req.session.ref && newsettings.invite && newsettings.invite.enabled == true) {
          const refId = req.session.ref;
          if (refId !== userinfo.id && (await db.get("users-" + refId))) {
            let refCoins = (await db.get("coins-" + refId)) || 0;
            refCoins += newsettings.invite.coins;
            await db.set("coins-" + refId, refCoins);

            let refInvites = (await db.get("invites-" + refId)) || [];
            refInvites.push({
              id: userinfo.id,
              username: userinfo.username,
              discriminator: userinfo.discriminator,
              coins: newsettings.invite.coins,
              date: new Date().toISOString(),
            });
            await db.set("invites-" + refId, refInvites);

            const userLog = require("../misc/userLog");
            await userLog(
              db,
              refId,
              "Invite Reward",
              `${userinfo.username} joined using your invite link! You earned ${newsettings.invite.coins.toFixed(2)} coins.`
            );
            log(
              "gifted coins",
              `${userinfo.username}#${userinfo.discriminator} signed up via an invite link, crediting \`${newsettings.invite.coins}\` coins to the referring user with the ID \`${refId}\`.`
            );
          }
          delete req.session.ref;
        }

        // Demo Mode: Use mock data for existing users
        if (demoMode.isDemoMode()) {
          let mockUser = demoMode.getMockPterodactylUser(userinfo);
          req.session.pterodactyl = mockUser;
        } else {
          // Normal Pterodactyl fetch
          let cacheaccount = await fetch(
            settings.pterodactyl.domain +
              "/api/application/users/" +
              (await db.get("users-" + userinfo.id)) +
              "?include=servers",
            {
              method: "get",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${settings.pterodactyl.key}`,
              },
            }
          );
          if (!cacheaccount.ok) {
            console.log(`oauth2 login ― Pterodactyl returned ${cacheaccount.status} ${cacheaccount.statusText} for Discord id ${userinfo.id}. Check the panel domain/API key in settings.json.`);
            return res.send(
              "An error has occured while attempting to get your user information."
            );
          }
          let cacheaccountinfo = JSON.parse(await cacheaccount.text());
          if (!cacheaccountinfo.attributes.relationships || !cacheaccountinfo.attributes.relationships.servers) {
            console.log(`oauth2 login ― Pterodactyl user for Discord id ${userinfo.id} has no "servers" relationship. The API key likely needs "Servers: Read" permission (Pterodactyl admin ➜ Application API) or dashboard/server pages will look empty.`);
          }
          req.session.pterodactyl = cacheaccountinfo.attributes;
        }

        req.session.userinfo = userinfo;

        // Save Discord profile metadata and index user ID
        await db.set("profile-" + userinfo.id, userinfo);
        let discordUsers = await db.get("discord-users-list") || [];
        if (!discordUsers.includes(userinfo.id)) {
          discordUsers.push(userinfo.id);
          await db.set("discord-users-list", discordUsers);
        }

        // Log login activity
        const userLog = require("../misc/userLog");
        await userLog(db, userinfo.id, "Login", `${userinfo.username}${userinfo.discriminator && userinfo.discriminator !== '0' ? '#' + userinfo.discriminator : ''} logged in to the dashboard.`);

        let theme = indexjs.get(req);
        if (customredirect) return res.redirect(customredirect);
        return res.redirect(
          theme.settings.redirect.callback
            ? theme.settings.redirect.callback
            : "/"
        );
      }
      res.send(
        "Not verified a Discord account. Please verify the email on your Discord account."
      );
    } else {
      res.redirect(`/login`);
    }
  });
};

function makeid(length) {
  let result = "";
  let characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}
