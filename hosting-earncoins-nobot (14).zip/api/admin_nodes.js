const fs = require("fs");
const fetch = require("node-fetch");
const settingsPath = "./settings.json";
const log = require("../misc/log");
const userLog = require("../misc/userLog");

module.exports.load = async function (app, db) {
  // Helper to verify admin status
  function isAdmin(req) {
    return req.session && req.session.pterodactyl && req.session.pterodactyl.root_admin === true;
  }

  // Save Locations List
  app.post("/api/admin/locations/save", async (req, res) => {
    if (!isAdmin(req)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

    const { locations } = req.body;
    if (!locations || typeof locations !== "object") {
      return res.status(400).json({ success: false, message: "Invalid locations object payload." });
    }

    try {
      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());
      settings.api.client.locations = locations;

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "admin save locations",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} updated the deployable locations configuration.`
      );

      await userLog(db, req.session.userinfo.id, "Manage Locations", "Updated deployable server locations node list configuration.");

      return res.json({ success: true, message: "Locations saved successfully!" });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write locations updates to settings.json." });
    }
  });

  // Save Eggs (Software) List
  app.post("/api/admin/eggs/save", async (req, res) => {
    if (!isAdmin(req)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

    const { eggs } = req.body;
    if (!eggs || typeof eggs !== "object") {
      return res.status(400).json({ success: false, message: "Invalid eggs object payload." });
    }

    try {
      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());
      settings.api.client.eggs = eggs;

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "admin save eggs",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} updated the deployable software eggs configuration.`
      );

      await userLog(db, req.session.userinfo.id, "Manage Software", "Updated deployable server software eggs configuration.");

      return res.json({ success: true, message: "Software configuration saved successfully!" });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write eggs updates to settings.json." });
    }
  });

  // Save Bot / External API Key settings (kept separate from the generic string-only
  // settings/update route so the "enabled" flag is stored as a real boolean).
  app.post("/api/admin/apikey/save", async (req, res) => {
    if (!isAdmin(req)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

    const { code, enabled } = req.body;
    if (typeof code !== "string" || !code.trim()) {
      return res.status(400).json({ success: false, message: "A non-empty API key is required." });
    }

    try {
      const settings = JSON.parse(fs.readFileSync(settingsPath).toString());
      if (!settings.api.client.api) settings.api.client.api = {};
      settings.api.client.api.code = code.trim();
      settings.api.client.api.enabled = enabled === true;

      fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));

      log(
        "admin save api key",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} updated the bot/external API key configuration.`
      );

      await userLog(db, req.session.userinfo.id, "Manage API Key", "Updated the bot/external API key configuration.");

      return res.json({ success: true, message: "API key settings saved successfully!" });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to write API key settings to settings.json." });
    }
  });

  // Helper to read live pterodactyl creds
  function pteroCreds() {
    const settings = JSON.parse(fs.readFileSync(settingsPath).toString());
    let domain = settings.pterodactyl.domain;
    if (domain.slice(-1) === "/") domain = domain.slice(0, -1);
    return { domain, key: settings.pterodactyl.key };
  }

  // List real Nodes from the Pterodactyl panel (used to populate the Node ID select).
  // The selected Node ID is used directly at server-creation time: we grab one of that
  // node's free allocations and deploy straight onto it.
  app.get("/api/admin/pterodactyl/nodes", async (req, res) => {
    if (!isAdmin(req)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

    try {
      const { domain, key } = pteroCreds();
      const response = await fetch(`${domain}/api/application/nodes`, {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${key}`,
        },
      });

      if (!response.ok) {
        return res.status(502).json({ success: false, message: `Panel responded with status ${response.status}.` });
      }

      const data = await response.json();
      const nodes = (data.data || []).map((n) => ({
        id: n.attributes.id,
        name: n.attributes.name,
        fqdn: n.attributes.fqdn,
      }));

      return res.json({ success: true, nodes });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to fetch nodes from the Pterodactyl panel." });
    }
  });

  // List Nests from the Pterodactyl panel (used to populate the Ptero Nest ID select)
  app.get("/api/admin/pterodactyl/nests", async (req, res) => {
    if (!isAdmin(req)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

    try {
      const { domain, key } = pteroCreds();
      const response = await fetch(`${domain}/api/application/nests`, {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${key}`,
        },
      });

      if (!response.ok) {
        return res.status(502).json({ success: false, message: `Panel responded with status ${response.status}.` });
      }

      const data = await response.json();
      const nests = (data.data || []).map((n) => ({
        id: n.attributes.id,
        name: n.attributes.name,
        description: n.attributes.description,
      }));

      return res.json({ success: true, nests });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to fetch nests from the Pterodactyl panel." });
    }
  });

  // List Eggs for a given Nest (used to populate the Ptero Egg ID select)
  app.get("/api/admin/pterodactyl/nests/:nestId/eggs", async (req, res) => {
    if (!isAdmin(req)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }

    const nestId = parseInt(req.params.nestId);
    if (!nestId) {
      return res.status(400).json({ success: false, message: "Invalid nest id." });
    }

    try {
      const { domain, key } = pteroCreds();
      const response = await fetch(`${domain}/api/application/nests/${nestId}/eggs`, {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${key}`,
        },
      });

      if (!response.ok) {
        return res.status(502).json({ success: false, message: `Panel responded with status ${response.status}.` });
      }

      const data = await response.json();
      const eggs = (data.data || []).map((e) => ({
        id: e.attributes.id,
        name: e.attributes.name,
        docker_image: e.attributes.docker_image,
        startup: e.attributes.startup,
      }));

      return res.json({ success: true, eggs });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Failed to fetch eggs from the Pterodactyl panel." });
    }
  });
};
