const fetch = require("node-fetch");
const settings = require("../settings.json");

module.exports = (userid, db) => {
  return new Promise(async (resolve, err) => {
    const pteroId = await db.get("users-" + userid);
    if (!pteroId) {
      console.log(`getPteroUser ― No Pterodactyl user id stored for Discord id ${userid} (db key "users-${userid}" is empty).`);
      return err("No linked Pterodactyl account for this user.");
    }

    let cacheaccount;
    try {
      cacheaccount = await fetch(
        settings.pterodactyl.domain +
          "/api/application/users/" +
          pteroId +
          "?include=servers",
        {
          method: "get",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${settings.pterodactyl.key}`,
          },
        }
      );
    } catch (fetchErr) {
      console.log(`getPteroUser ― Network error reaching ${settings.pterodactyl.domain}: ${fetchErr.message}`);
      return err("Could not reach the Pterodactyl panel.");
    }

    if (!cacheaccount.ok) {
      console.log(`getPteroUser ― Pterodactyl returned ${cacheaccount.status} ${cacheaccount.statusText} for user ${pteroId}. Check the API key's permissions (needs Users: Read and Servers: Read).`);
      return err(`Pterodactyl account fetch failed (${cacheaccount.status}).`);
    }

    let cacheaccountinfo;
    try {
      cacheaccountinfo = JSON.parse(await cacheaccount.text());
    } catch (parseErr) {
      console.log(`getPteroUser ― Failed to parse Pterodactyl response for user ${pteroId}: ${parseErr.message}`);
      return err("Malformed response from Pterodactyl.");
    }

    if (!cacheaccountinfo.attributes) {
      console.log(`getPteroUser ― Pterodactyl response for user ${pteroId} had no "attributes" field: ${JSON.stringify(cacheaccountinfo).slice(0, 300)}`);
      return err("Pterodactyl account data was empty.");
    }

    if (!cacheaccountinfo.attributes.relationships || !cacheaccountinfo.attributes.relationships.servers) {
      console.log(`getPteroUser ― Pterodactyl user ${pteroId} loaded but has no "servers" relationship included. This usually means the API key is missing "Servers: Read" permission in the Pterodactyl admin panel (Application API keys), so the dashboard/server list will show as empty even though servers exist.`);
    }

    resolve(cacheaccountinfo);
  });
};
