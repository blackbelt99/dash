module.exports = `
// Determine the scheme based on the current protocol
const scheme = document.location.protocol === "https:" ? "wss" : "ws";

// Get the hostname and port from the current URL
const hostname = window.location.hostname;
const port = window.location.port ? ':' + window.location.port : '';

let connection = null;
let timer = everywhat;
let hascoin = 0;
let totalDurationSeconds = 0;
let countdownInterval = null;
let sessionInterval = null;
let isTabActive = true;

const arciotimerEl = document.getElementById("arciotimer");
const arciogainedcoinsEl = document.getElementById("arciogainedcoins");
const sessionDurationEl = document.getElementById("sessionDuration");
const afkStatusEl = document.getElementById("afk-status");

function updateStatusText(text, isGreen, statusClass) {
  if (afkStatusEl) {
    const dotColor = isGreen ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500';
    afkStatusEl.innerHTML = \`<span class="h-2 w-2 rounded-full \${dotColor}"></span><span>\${text}</span>\`;
    afkStatusEl.className = "flex items-center space-x-2 px-4 py-1.5 text-xs font-semibold rounded-full " + statusClass;
  }
}

function startAFK() {
  if (connection) return; // Already running

  connection = new WebSocket(\`\${scheme}://\${hostname}\${port}/\${wspath}\`);
  
  connection.onopen = function() {
    updateStatusText("AFK Active - Earning Coins", true, "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-lg shadow-emerald-500/5");
  };

  connection.onclose = function() {
    connection = null;
    if (isTabActive) {
      // Reconnect if it was closed unexpectedly
      setTimeout(startAFK, 2000);
    }
  };

  // Setup visual interval
  if (!countdownInterval) {
    countdownInterval = setInterval(() => {
      if (!connection) return; // Don't tick if paused
      timer--;
      if (timer < 1) {
        hascoin += gaincoins;
        if (arciogainedcoinsEl) arciogainedcoinsEl.innerText = hascoin;
        timer = everywhat;
      }
      if (arciotimerEl) arciotimerEl.innerText = timer;
    }, 1000);
  }
}

function stopAFK() {
  if (connection) {
    connection.close();
    connection = null;
  }
  updateStatusText("AFK Paused - Keep tab open & active", false, "bg-amber-500/10 text-amber-400 border border-amber-500/20 shadow-lg shadow-amber-500/5");
}

// Track session duration
if (!sessionInterval) {
  sessionInterval = setInterval(() => {
    if (connection) {
      totalDurationSeconds++;
      let hours = Math.floor(totalDurationSeconds / 3600);
      let minutes = Math.floor((totalDurationSeconds % 3600) / 60);
      let seconds = totalDurationSeconds % 60;
      let durationString = '';
      if (hours > 0) durationString += hours + "h ";
      if (minutes > 0 || hours > 0) durationString += minutes + "m ";
      durationString += seconds + "s";
      if (sessionDurationEl) sessionDurationEl.innerText = durationString;
    }
  }, 1000);
}

// Focus/Visibility event handlers
function handleVisibilityChange() {
  if (document.hidden) {
    isTabActive = false;
    stopAFK();
  } else {
    isTabActive = true;
    startAFK();
  }
}

document.addEventListener("visibilitychange", handleVisibilityChange);
window.addEventListener("focus", () => {
  isTabActive = true;
  startAFK();
});
window.addEventListener("blur", () => {
  isTabActive = false;
  stopAFK();
});

// Initial boot
if (!document.hidden) {
  startAFK();
} else {
  stopAFK();
}
`;
