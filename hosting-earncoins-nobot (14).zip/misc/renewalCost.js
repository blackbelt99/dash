/**
 * Calculates how many coins it should cost to renew a server, based on the
 * coin-store price of the resources (RAM/Disk/CPU) that server is running.
 * This replaces a single flat renewal cost with one proportional to what the
 * user "spent" (in coins) to get that server's specs in the first place.
 *
 * Falls back to the flat global renewal cost (settings.api.renewal.cost, then
 * settings.api.client.coins.renewalCost, then 20) if the coin store is
 * disabled/misconfigured, or if the computed cost comes out to 0.
 *
 * @param {number} ram  Memory in MB
 * @param {number} disk Disk in MB
 * @param {number} cpu  CPU in %
 * @param {object} settings Parsed settings.json
 * @returns {number} Coin cost, rounded up to the nearest whole coin
 */
module.exports = function calculateRenewalCost(ram, disk, cpu, settings) {
  const fallback =
    (settings.api && settings.api.renewal && settings.api.renewal.cost) ||
    (settings.api && settings.api.client && settings.api.client.coins && settings.api.client.coins.renewalCost) ||
    20;

  const store = settings.api && settings.api.client && settings.api.client.coins && settings.api.client.coins.store;
  if (!store || store.enabled !== true) return fallback;

  ram = Number(ram) || 0;
  disk = Number(disk) || 0;
  cpu = Number(cpu) || 0;

  let cost = 0;
  if (store.ram && store.ram.per) cost += (ram / store.ram.per) * store.ram.cost;
  if (store.disk && store.disk.per) cost += (disk / store.disk.per) * store.disk.cost;
  if (store.cpu && store.cpu.per) cost += (cpu / store.cpu.per) * store.cpu.cost;

  cost = Math.ceil(cost);

  return cost > 0 ? cost : fallback;
};
