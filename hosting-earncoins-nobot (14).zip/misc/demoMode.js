/**
 * Demo Mode Helper
 * 
 * This module provides mock data and bypass functions for running Helix
 * without a Pterodactyl panel. Perfect for UI development and testing.
 */

const settings = require('../settings.json');

/**
 * Check if demo mode is enabled
 */
function isDemoMode() {
    return settings.demoMode && settings.demoMode.enabled === true;
}

/**
 * Get mock pterodactyl user data
 */
function getMockPterodactylUser(userinfo) {
    const mockUser = settings.demoMode.mockUser || {};
    
    return {
        id: 1,
        external_id: userinfo ? userinfo.id : 'demo-user-id',
        uuid: 'demo-uuid-' + Date.now(),
        username: mockUser.username || 'DemoUser',
        email: mockUser.email || 'demo@example.com',
        first_name: userinfo ? userinfo.username : 'Demo',
        last_name: userinfo ? '#' + (userinfo.discriminator || '0000') : 'User',
        language: 'en',
        root_admin: mockUser.isAdmin !== false, // Default to admin
        "2fa": false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        relationships: {
            servers: {
                object: 'list',
                data: [
                    {
                        object: 'server',
                        attributes: {
                            id: 1,
                            external_id: null,
                            uuid: 'demo-server-1-uuid',
                            identifier: 'demo1abc',
                            name: 'Demo Server 1',
                            description: 'This is a demo server',
                            status: null,
                            suspended: false,
                            limits: {
                                memory: 2048,
                                swap: 0,
                                disk: 10240,
                                io: 500,
                                cpu: 200
                            },
                            feature_limits: {
                                databases: 2,
                                allocations: 1,
                                backups: 3
                            },
                            user: 1,
                            node: 1,
                            allocation: 1,
                            nest: 1,
                            egg: 5,
                            container: {
                                startup_command: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar server.jar',
                                image: 'ghcr.io/pterodactyl/yolks:java_17',
                                installed: true,
                                environment: {
                                    SERVER_JARFILE: 'server.jar',
                                    BUILD_NUMBER: 'latest'
                                }
                            },
                            updated_at: new Date().toISOString(),
                            created_at: new Date().toISOString()
                        }
                    },
                    {
                        object: 'server',
                        attributes: {
                            id: 2,
                            external_id: null,
                            uuid: 'demo-server-2-uuid',
                            identifier: 'demo2xyz',
                            name: 'Demo Server 2',
                            description: 'Another demo server',
                            status: null,
                            suspended: false,
                            limits: {
                                memory: 1024,
                                swap: 0,
                                disk: 5120,
                                io: 500,
                                cpu: 100
                            },
                            feature_limits: {
                                databases: 1,
                                allocations: 1,
                                backups: 2
                            },
                            user: 1,
                            node: 1,
                            allocation: 2,
                            nest: 1,
                            egg: 3,
                            container: {
                                startup_command: 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar bungeecord.jar',
                                image: 'ghcr.io/pterodactyl/yolks:java_17',
                                installed: true,
                                environment: {
                                    SERVER_JARFILE: 'bungeecord.jar',
                                    BUNGEE_VERSION: 'latest'
                                }
                            },
                            updated_at: new Date().toISOString(),
                            created_at: new Date().toISOString()
                        }
                    }
                ]
            }
        }
    };
}

/**
 * Mock fetch function that returns demo data
 */
async function mockFetch(url, options = {}) {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 100));

    // Parse the URL to determine what to return
    if (url.includes('/api/application/users')) {
        if (options.method === 'post') {
            // Creating a new user
            return {
                status: 201,
                statusText: 'Created',
                json: async () => ({
                    object: 'user',
                    attributes: getMockPterodactylUser()
                }),
                text: async () => JSON.stringify({
                    object: 'user',
                    attributes: getMockPterodactylUser()
                })
            };
        } else {
            // Getting user info
            return {
                status: 200,
                statusText: 'OK',
                json: async () => ({
                    object: 'user',
                    attributes: getMockPterodactylUser()
                }),
                text: async () => JSON.stringify({
                    object: 'user',
                    attributes: getMockPterodactylUser()
                })
            };
        }
    }

    if (url.includes('/api/application/servers')) {
        if (options.method === 'post') {
            // Creating a new server
            const newServerId = Math.floor(Math.random() * 10000) + 3;
            return {
                status: 201,
                statusText: 'Created',
                json: async () => ({
                    object: 'server',
                    attributes: {
                        id: newServerId,
                        uuid: 'demo-server-' + newServerId + '-uuid',
                        identifier: 'demo' + newServerId,
                        name: 'New Demo Server',
                        suspended: false,
                        limits: {
                            memory: 1024,
                            disk: 5120,
                            cpu: 100
                        }
                    }
                }),
                text: async () => JSON.stringify({
                    object: 'server',
                    attributes: {
                        id: newServerId,
                        uuid: 'demo-server-' + newServerId + '-uuid',
                        identifier: 'demo' + newServerId,
                        name: 'New Demo Server',
                        suspended: false,
                        limits: {
                            memory: 1024,
                            disk: 5120,
                            cpu: 100
                        }
                    }
                })
            };
        } else if (options.method === 'patch') {
            // Updating a server
            return {
                status: 200,
                statusText: 'OK',
                json: async () => ({
                    object: 'server',
                    attributes: {
                        id: 1,
                        name: 'Updated Demo Server'
                    }
                }),
                text: async () => JSON.stringify({
                    object: 'server',
                    attributes: {
                        id: 1,
                        name: 'Updated Demo Server'
                    }
                })
            };
        } else if (options.method === 'delete') {
            // Deleting a server
            return {
                status: 204,
                statusText: 'No Content',
                json: async () => ({}),
                text: async () => ''
            };
        }
    }

    // Default response
    return {
        status: 200,
        statusText: 'OK',
        json: async () => ({ success: true }),
        text: async () => JSON.stringify({ success: true })
    };
}

module.exports = {
    isDemoMode,
    getMockPterodactylUser,
    mockFetch
};
