const fetch = require("node-fetch");
const fs = require("fs");
const getServers = require("./getServers");
const log = require("./log");
const userLog = require("./userLog");
const calculateRenewalCost = require("./renewalCost");

module.exports.start = function (db) {
  // Run one-off cleanup of legacy seeded renewal records that have no ownerId
  cleanupLegacyRenewals();

  // Check renewals once on startup, then every 10 minutes
  checkRenewals();
  setInterval(checkRenewals, 10 * 60 * 1000);

  async function cleanupLegacyRenewals() {
    try {
      console.log("Renewal System ― Running legacy renewal records cleanup...");
      const servers = await getServers();
      if (!Array.isArray(servers)) return;

      for (const server of servers) {
        const serverId = server.attributes.id;
        const renewal = await db.get("renewal-" + serverId);
        if (renewal && (renewal.ownerId === null || !renewal.ownerId)) {
          await db.delete("renewal-" + serverId);
          console.log(`Renewal System ― Removed legacy renewal record for server "${server.attributes.name}" (ID: ${serverId}). Set to Permanent.`);
        }
      }
      console.log("Renewal System ― Legacy renewal cleanup complete.");
    } catch (err) {
      console.error("Renewal System ― Error cleaning up legacy renewals:", err);
    }
  }

  async function checkRenewals() {
    try {
      // Load current settings dynamically to capture admin changes instantly
      const settings = JSON.parse(fs.readFileSync("./settings.json").toString());

      // If renewal system is disabled globally, skip checking
      if (!settings.api.renewal || settings.api.renewal.enabled !== true) {
        return;
      }

      const servers = await getServers();
      if (!Array.isArray(servers)) return;

      const renewalInterval = (settings.api.renewal && settings.api.renewal.interval) || 7;
      const gracePeriod = (settings.api.renewal && settings.api.renewal.gracePeriod) || 3;

      for (const server of servers) {
        const serverId = server.attributes.id;
        const name = server.attributes.name;
        
        let renewal = await db.get("renewal-" + serverId);

        // If no renewal record exists in DB, it means this server does NOT require renewal. Ignore it!
        if (!renewal) {
          continue;
        }

        // If the server has a custom structure (old versions might have stored it as a raw number), convert it
        if (typeof renewal === "number") {
          renewal = {
            nextRenewal: renewal,
            suspendedAt: null,
            ownerId: null,
            autoRenew: false
          };
          await db.set("renewal-" + serverId, renewal);
        }

        // Servers seeded before per-server pricing existed won't have a `cost` yet.
        // Backfill it from the server's actual resource specs so renewals stay
        // proportional to what that server is worth, instead of a flat fallback.
        if (typeof renewal.cost !== "number") {
          const limits = server.attributes.limits || {};
          renewal.cost = calculateRenewalCost(limits.memory, limits.disk, limits.cpu, settings);
          await db.set("renewal-" + serverId, renewal);
        }
        const renewalCost = renewal.cost;

        const now = Date.now();

        // 1. Check if renewal date has passed
        if (now > renewal.nextRenewal) {
          
          // 1.1 Try Auto-Renewal if enabled and ownerId is cached
          if (renewal.autoRenew === true && renewal.ownerId) {
            let userCoins = await db.get("coins-" + renewal.ownerId);
            if (typeof userCoins !== "number") userCoins = 0;

            if (userCoins >= renewalCost) {
              // Deduct coins & extend renewal
              userCoins -= renewalCost;
              await db.set("coins-" + renewal.ownerId, userCoins);

              renewal.nextRenewal = Date.now() + renewalInterval * 24 * 60 * 60 * 1000;
              renewal.suspendedAt = null;
              await db.set("renewal-" + serverId, renewal);

              // Instantly call Unsuspend on Pterodactyl in case it was suspended
              await fetch(
                settings.pterodactyl.domain + "/api/application/servers/" + serverId + "/unsuspend",
                {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${settings.pterodactyl.key}`
                  }
                }
              );

              log(
                "auto-renewed server",
                `Server \`${name}\` (ID: ${serverId}) was successfully auto-renewed for ${renewalInterval} days costing ${renewalCost} coins.`
              );

              await userLog(db, renewal.ownerId, "Auto-Renew Server", `Server "${name}" was automatically renewed for ${renewalInterval} days (Cost: ${renewalCost} coins).`);
              continue; // Skip suspension checks
            } else {
              // Log failed auto-renewal
              await userLog(db, renewal.ownerId, "Auto-Renew Failed", `Auto-Renewal for server "${name}" failed due to insufficient coins.`);
            }
          }

          // 1.2 Proceed with standard suspension
          if (!renewal.suspendedAt) {
            renewal.suspendedAt = now;
            await db.set("renewal-" + serverId, renewal);

            // Fetch to Pterodactyl Suspend endpoint
            await fetch(
              settings.pterodactyl.domain + "/api/application/servers/" + serverId + "/suspend",
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${settings.pterodactyl.key}`
                }
              }
            );

            log(
              "suspended server (renewal)",
              `Server \`${name}\` (ID: ${serverId}) was suspended due to expired renewal.`
            );
          } else {
            // 2. Already suspended. Check if grace period has passed (gracePeriod in days)
            if (now > renewal.suspendedAt + gracePeriod * 24 * 60 * 60 * 1000) {
              // Delete server permanently
              await fetch(
                settings.pterodactyl.domain + "/api/application/servers/" + serverId,
                {
                  method: "DELETE",
                  headers: {
                    Authorization: `Bearer ${settings.pterodactyl.key}`
                  }
                }
              );

              await db.delete("renewal-" + serverId);

              log(
                "deleted server (renewal)",
                `Server \`${name}\` (ID: ${serverId}) was deleted permanently after ${gracePeriod} days of suspension.`
              );

              if (renewal.ownerId) {
                await userLog(db, renewal.ownerId, "Server Purged", `Server "${name}" was permanently deleted after remaining suspended for ${gracePeriod} days.`);
              }
            }
          }
        } else {
          // 3. Renewal date is active. If it was marked suspended, unsuspend it
          if (renewal.suspendedAt) {
            renewal.suspendedAt = null;
            await db.set("renewal-" + serverId, renewal);

            // Fetch to Pterodactyl Unsuspend endpoint
            await fetch(
              settings.pterodactyl.domain + "/api/application/servers/" + serverId + "/unsuspend",
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${settings.pterodactyl.key}`
                }
              }
            );

            log(
              "unsuspended server (renewal)",
              `Server \`${name}\` (ID: ${serverId}) was unsuspended.`
            );
          }
        }
      }
    } catch (err) {
      console.error("Error in renewal cron job:", err);
    }
  }
};
