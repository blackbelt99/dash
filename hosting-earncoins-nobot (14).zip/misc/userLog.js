/**
 * Log a user activity to the database (tracks last 10 activities).
 * @param {object} db - Keyv database instance
 * @param {string} userId - Discord User ID
 * @param {string} action - Action title/type
 * @param {string} description - Action description
 */
module.exports = async function userLog(db, userId, action, description) {
  try {
    if (!userId) return;
    let logs = await db.get("logs-" + userId) || [];
    
    // Add new log to the start of the array (most recent first)
    logs.unshift({
      action: action,
      description: description,
      timestamp: new Date().toISOString()
    });

    // Limit to last 10 activities
    if (logs.length > 10) {
      logs = logs.slice(0, 10);
    }

    await db.set("logs-" + userId, logs);
  } catch (err) {
    console.error("Failed to write user activity log:", err);
  }
};
