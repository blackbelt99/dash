const sqlite3 = require("sqlite3").verbose();
const path = require("path");
function enableWal() {
  const dbPath = path.resolve(__dirname, "../database.sqlite");
  console.log(`Opening SQLite database at: ${dbPath}`);
  
  const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
      console.error("Failed to open database:", err);
      return;
    }
    
    db.serialize(() => {
      // 1. Check current journal mode
      db.get("PRAGMA journal_mode;", (err, row) => {
        if (err) {
          console.error("Failed to get current journal mode:", err);
          return;
        }
        console.log(`Current journal mode: ${row.journal_mode}`);
        
        // 2. Enable WAL
        db.run("PRAGMA journal_mode=WAL;", (err) => {
          if (err) {
            console.error("Failed to set journal mode to WAL:", err);
            return;
          }
          
          // 3. Confirm WAL is set
          db.get("PRAGMA journal_mode;", (err, row) => {
            if (err) {
              console.error("Failed to verify journal mode:", err);
              return;
            }
            console.log(`New journal mode set: ${row.journal_mode}`);
            
            // 4. Set busy timeout to 5000ms to prevent instant lock errors
            db.run("PRAGMA busy_timeout=5000;", (err) => {
              if (err) {
                console.error("Failed to set busy_timeout:", err);
              } else {
                console.log("Busy timeout set to 5000ms successfully.");
              }
              db.close();
            });
          });
        });
      });
    });
  });
}
enableWal();
